window.addEventListener("DOMContentLoaded", () => {
  console.log("Loaded Scripts");
});
